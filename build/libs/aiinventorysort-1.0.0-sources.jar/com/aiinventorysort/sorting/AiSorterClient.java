package com.aiinventorysort.sorting;

import com.aiinventorysort.AiInventorySort;
import com.aiinventorysort.config.ModConfig;
import com.google.gson.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

@Environment(EnvType.CLIENT)
public class AiSorterClient implements AiSorter {

    private static final String API_URL = "https://ollama.com/v1/chat/completions";
    private static final String MODEL   = "gpt-oss:20b-cloud"; // Ollama Cloud model
    private static final Gson GSON      = new Gson();

    // Slot layout references
    private static final List<Integer> LEFT_THIRD   = List.of(9,10,11,18,19,20,27,28,29);
    private static final List<Integer> MIDDLE_THIRD = List.of(12,13,14,21,22,23,30,31,32);
    private static final List<Integer> RIGHT_THIRD  = List.of(15,16,17,24,25,26,33,34,35);

    @Override
    public void sortAsync(Consumer<String> onDone) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) { onDone.accept("No player found."); return; }

        List<SlotInfo> slots = captureInventory(mc);
        if (slots.isEmpty()) { onDone.accept(null); return; }

        CompletableFuture.runAsync(() -> {
            try {
                int[] desiredPlayerSlots = callApi(slots);
                mc.execute(() -> {
                    applySort(mc, slots, desiredPlayerSlots);
                    onDone.accept(null);
                });
            } catch (Exception e) {
                AiInventorySort.LOGGER.error("AI sort failed", e);
                mc.execute(() -> onDone.accept("Error: " + e.getMessage()));
            }
        });
    }

    @Override
    public void takeSnapshot() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        List<String> layout = new ArrayList<>(36);
        for (int i = 0; i < 36; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            layout.add(stack.method_7960() ? null : class_7923.field_41178.method_10221(stack.method_7909()).toString());
        }
        ModConfig.get().snapshotLayout = layout;
        ModConfig.save();
    }

    private List<SlotInfo> captureInventory(class_310 mc) {
        List<SlotInfo> slots = new ArrayList<>();
        for (int i = 0; i < 36; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960()) continue;

            String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            boolean isEnchanted = stack.method_58694(class_9334.field_49633) != null
                    && !stack.method_58694(class_9334.field_49633).method_57543();

            List<ShulkerSlot> shulkerContents = null;
            if (isShulkerBox(itemId)) shulkerContents = readShulkerContents(stack);

            slots.add(new SlotInfo(i, itemId, stack.method_7947(), isEnchanted, shulkerContents));
        }
        return slots;
    }

    private boolean isShulkerBox(String itemId) {
        return itemId.contains("shulker_box");
    }

    private List<ShulkerSlot> readShulkerContents(class_1799 shulker) {
        class_9288 container = shulker.method_58694(class_9334.field_49622);
        if (container == null) return Collections.emptyList();

        List<ShulkerSlot> contents = new ArrayList<>();
        container.method_59714().forEach(stack -> {
            if (!stack.method_7960()) {
                contents.add(new ShulkerSlot(class_7923.field_41178.method_10221(stack.method_7909()).toString(), stack.method_7947()));
            }
        });
        return contents;
    }

    private String buildPrompt(List<SlotInfo> slots) {
        StringBuilder sb = new StringBuilder();
        sb.append("""
You sort a Minecraft inventory into fixed slots.

HOTBAR (0–8, priority order, skip if none):
0 sword (netherite>diamond>iron)
1 mace
2 spear
3 axe
4 pickaxe
5 elytra or chestplate (prefer elytra)
6 shovel
7 best utility item
8 best food

MAIN (9–35):
LEFT  (9,10,11,18,19,20,27,28,29): shulkers/storage
MID   (12,13,14,21,22,23,30,31,32): tools, weapons, armor, blocks, misc
RIGHT (15,16,17,24,25,26,33,34,35): food/consumables

Rules:
- Fill each section in slot order
- Each item gets exactly one unique slot
- Unassigned hotbar items go to MAIN
- Shulkers ALWAYS go LEFT (ignore contents)

Output:
JSON only, same order:
[{"from":X,"to":Y},...]

Inventory:
""");
        for (SlotInfo s : slots) {
            sb.append("slot ").append(s.slot()).append(": ").append(s.itemId()).append(" x").append(s.count());
            if (s.enchanted()) sb.append(" [enchanted]");
            if (s.shulkerContents() != null && !s.shulkerContents().isEmpty()) {
                sb.append(" [shulker contents: ");
                List<String> parts = new ArrayList<>();
                for (ShulkerSlot ss : s.shulkerContents()) parts.add(ss.itemId() + " x" + ss.count());
                sb.append(String.join(", ", parts)).append("]");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    private int[] callApi(List<SlotInfo> slots) throws Exception {
        String apiKey = ModConfig.get().apiKey;
        if (apiKey == null || apiKey.isBlank())
            throw new IllegalStateException("No API key set. Put your Ollama API key in config.");
        apiKey = apiKey.trim();

        JsonObject requestBody = new JsonObject();
        requestBody.addProperty("model", MODEL);

        JsonArray messages = new JsonArray();
        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", buildPrompt(slots));
        messages.add(userMsg);
        requestBody.add("messages", messages);

        byte[] body = GSON.toJson(requestBody).getBytes(StandardCharsets.UTF_8);

        HttpURLConnection conn = (HttpURLConnection) URI.create(API_URL).toURL().openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setDoOutput(true);
        conn.setConnectTimeout(10_000);
        conn.setReadTimeout(300_000);

        try (OutputStream os = conn.getOutputStream()) { os.write(body); }

        int status = conn.getResponseCode();
        InputStream is = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
        String response = new String(is.readAllBytes(), StandardCharsets.UTF_8);

        if (status < 200 || status >= 300)
            throw new IOException("Ollama API error " + status + ": " + response);

        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
        String text = json.getAsJsonArray("choices")
                         .get(0).getAsJsonObject()
                         .get("message").getAsJsonObject()
                         .get("content").getAsString().trim();

        // REMOVE MARKDOWN WRAPPERS
        if (text.startsWith("```")) {
            text = text.replaceFirst("^```json\\s*", "")
               .replaceFirst("^```\\s*", "")
               .replaceAll("```$", "")
               .trim();
        }

        AiInventorySort.LOGGER.info("Ollama sort response: " + text);

        JsonArray arr = JsonParser.parseString(text).getAsJsonArray();
        Map<Integer, Integer> fromTo = new LinkedHashMap<>();
        for (JsonElement el : arr) {
            JsonObject obj = el.getAsJsonObject();
            fromTo.put(obj.get("from").getAsInt(), obj.get("to").getAsInt());
        }

        int[] result = new int[slots.size()];
        for (int i = 0; i < slots.size(); i++) {
            int from = slots.get(i).slot();
            if (!fromTo.containsKey(from))
                throw new IOException("Ollama didn't assign a target for slot " + from);
            result[i] = fromTo.get(from);
        }
        return result;
    }

    private void applySort(class_310 mc, List<SlotInfo> original, int[] desiredPlayerSlots) {
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1724.field_7512 == null) return;
        if (desiredPlayerSlots.length != original.size()) {
            AiInventorySort.LOGGER.error("Ollama returned wrong number of slots: expected " + original.size() + " got " + desiredPlayerSlots.length);
            return;
        }

        boolean inventoryOpen = mc.field_1724.field_7512.field_7761.size() > 36;
        int screenSlotCount = mc.field_1724.field_7512.field_7761.size();
        int syncId = mc.field_1724.field_7512.field_7763;

        AiInventorySort.LOGGER.info("=== applySort DEBUG ===");
        AiInventorySort.LOGGER.info("Inventory open: " + inventoryOpen);
        AiInventorySort.LOGGER.info("Screen slot count: " + screenSlotCount);
        AiInventorySort.LOGGER.info("SyncId: " + syncId);
        AiInventorySort.LOGGER.info("Screen handler class: " + mc.field_1724.field_7512.getClass().getName());

        Map<Integer, Integer> targetFor = new LinkedHashMap<>();
        for (int i = 0; i < original.size(); i++) {
            int from = original.get(i).slot();
            int to   = desiredPlayerSlots[i];
            if (!inventoryOpen && from >= 9) continue;
            if (!inventoryOpen && to >= 9) continue;
            if (from != to) targetFor.put(from, to);
        }

        AiInventorySort.LOGGER.info("Moves to make: " + targetFor.size());
        for (Map.Entry<Integer, Integer> entry : targetFor.entrySet()) {
            int fromScreen = playerSlotToScreenSlot(entry.getKey());
            int toScreen   = playerSlotToScreenSlot(entry.getValue());
            AiInventorySort.LOGGER.info("  playerSlot " + entry.getKey() + " -> " + entry.getValue()
                    + "  (screenSlot " + fromScreen + " -> " + toScreen + ")");
        }

        Set<Integer> done = new HashSet<>();
        for (int start : new ArrayList<>(targetFor.keySet())) {
            if (done.contains(start)) continue;
            List<Integer> chain = new ArrayList<>();
            Set<Integer> seen = new LinkedHashSet<>();
            int cur = start;
            while (!done.contains(cur) && targetFor.containsKey(cur) && seen.add(cur)) { chain.add(cur); cur = targetFor.get(cur); }
            boolean isCycle = chain.contains(cur);
            done.addAll(chain);
            if (chain.isEmpty()) continue;

            AiInventorySort.LOGGER.info("Processing chain: " + chain + " isCycle=" + isCycle);

            if (isCycle) {
                int firstScreen = playerSlotToScreenSlot(chain.get(0));
                AiInventorySort.LOGGER.info("  [cycle] picking up from screenSlot " + firstScreen);
                mc.field_1761.method_2906(syncId, firstScreen, 0, class_1713.field_7790, mc.field_1724);

                for (int i = 1; i < chain.size(); i++) {
                    int targetScreen = playerSlotToScreenSlot(targetFor.get(chain.get(i - 1)));
                    AiInventorySort.LOGGER.info("  [cycle] clicking screenSlot " + targetScreen);
                    mc.field_1761.method_2906(syncId, targetScreen, 0, class_1713.field_7790, mc.field_1724);
                }

                int lastScreen = playerSlotToScreenSlot(targetFor.get(chain.get(chain.size() - 1)));
                AiInventorySort.LOGGER.info("  [cycle] final click screenSlot " + lastScreen);
                mc.field_1761.method_2906(syncId, lastScreen, 0, class_1713.field_7790, mc.field_1724);
            } else {
                int firstScreen = playerSlotToScreenSlot(chain.get(0));
                AiInventorySort.LOGGER.info("  [chain] picking up from screenSlot " + firstScreen);
                mc.field_1761.method_2906(syncId, firstScreen, 0, class_1713.field_7790, mc.field_1724);

                for (int from : chain) {
                    int targetScreen = playerSlotToScreenSlot(targetFor.get(from));
                    AiInventorySort.LOGGER.info("  [chain] clicking screenSlot " + targetScreen);
                    mc.field_1761.method_2906(syncId, targetScreen, 0, class_1713.field_7790, mc.field_1724);
                }

                if (!mc.field_1724.field_7512.method_34255().method_7960()) {
                    AiInventorySort.LOGGER.info("  [chain] cursor not empty, returning to screenSlot " + firstScreen);
                    mc.field_1761.method_2906(syncId, firstScreen, 0, class_1713.field_7790, mc.field_1724);
                }
            }
        }
        AiInventorySort.LOGGER.info("AI sort applied " + targetFor.size() + " moves. Inventory open? " + inventoryOpen);
        AiInventorySort.LOGGER.info("=== applySort DEBUG END ===");
    }

    private int playerSlotToScreenSlot(int playerSlot) {
        return playerSlot < 9 ? playerSlot + 36 : playerSlot;
    }

    private record SlotInfo(int slot, String itemId, int count, boolean enchanted, List<ShulkerSlot> shulkerContents) {}
    private record ShulkerSlot(String itemId, int count) {}
}