package com.aiinventorysort.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes the protected x/y position fields of {@link net.minecraft.class_465}
 * so {@link com.aiinventorysort.client.InventoryButtonInjector} can place buttons correctly.
 */
@Mixin(net.minecraft.class_465.class)
public interface InventoryScreenMixin {

    @Accessor("x")
    int getX();

    @Accessor("y")
    int getY();
}
