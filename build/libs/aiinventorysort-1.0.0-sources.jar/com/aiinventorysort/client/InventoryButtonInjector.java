package com.aiinventorysort.client;

import com.aiinventorysort.client.mixin.InventoryScreenMixin;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_465;

public class InventoryButtonInjector {

    public void injectButton(class_465<?> screen, Runnable onSort) {
        // Use the mixin accessor to get the protected x/y fields from HandledScreen
        InventoryScreenMixin accessor = (InventoryScreenMixin) screen;
        int guiLeft = accessor.getX();
        int guiTop  = accessor.getY();

        Screens.getButtons(screen).add(
            class_4185.method_46430(class_2561.method_43470("AI Sort"), button -> {
                if (onSort != null) onSort.run();
            })
            .method_46434(guiLeft + 10, guiTop + 30, 60, 20)
            .method_46431()
        );
    }
}
