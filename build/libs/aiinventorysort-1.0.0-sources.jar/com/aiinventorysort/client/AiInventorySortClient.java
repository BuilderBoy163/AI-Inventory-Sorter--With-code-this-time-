package com.aiinventorysort.client;

import com.aiinventorysort.AiInventorySort;
import com.aiinventorysort.client.mixin.InventoryScreenMixin;
import com.aiinventorysort.sorting.AiSorterClient;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_465;

@Environment(EnvType.CLIENT)
public class AiInventorySortClient implements ClientModInitializer {

    private final AiSorterClient sorter = new AiSorterClient();

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof class_465<?> handledScreen) {
                injectSorterButton(handledScreen);
            }
        });
    }

    private void injectSorterButton(class_465<?> screen) {
        InventoryScreenMixin accessor = (InventoryScreenMixin) screen;
        int guiLeft = accessor.getX();
        int guiTop  = accessor.getY();

        // Standard inventory grid: 9 slots wide, each slot 18px, starting at x+8
        // Top-right slot left edge = guiLeft + 8 + (8 * 18) = guiLeft + 152
        // Button is 10px wide, so place at guiLeft + 152 + (18/2) - 5 = guiLeft + 158
        // Place it just above the top row: guiTop + 84 - 12 = guiTop + 72
        Screens.getButtons(screen).add(
            class_4185.method_46430(class_2561.method_43470("S"), button -> {
                button.field_22763 = false;
                sorter.sortAsync(result -> {
                    class_310 mc = class_310.method_1551();
                    mc.execute(() -> {
                        button.field_22763 = true;
                        if (result != null) {
                            AiInventorySort.LOGGER.warn("AI Sort error: " + result);
                        } else {
                            AiInventorySort.LOGGER.info("Inventory sorted by AI!");
                        }
                    });
                });
            })
            .method_46434(guiLeft + 158, guiTop + 52, 10, 10)
            .method_46431()
        );
    }
}