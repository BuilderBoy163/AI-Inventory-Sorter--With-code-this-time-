package com.aiinventorysort.client.gui;

import com.aiinventorysort.config.ModConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Simple in-game config screen.
 * Open it from the Mods menu (ModMenu integration) or via the /aiinvsort config command.
 */
public class ConfigScreen extends class_437 {

    private final class_437 parent;
    private class_342 apiKeyField;

    public ConfigScreen(class_437 parent) {
        super(class_2561.method_43470("AI Inventory Sort — Config"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;
        int centerY = field_22790 / 2;

        // API key input
        apiKeyField = new class_342(field_22793, centerX - 150, centerY - 20, 300, 20,
                class_2561.method_43470("Anthropic API key"));
        apiKeyField.method_1880(200);
        apiKeyField.method_1852(ModConfig.get().apiKey);
        apiKeyField.method_47404(class_2561.method_43470("sk-ant-..."));
        method_37063(apiKeyField);

        // Save button
        method_37063(class_4185.method_46430(class_2561.method_43470("Save"), btn -> {
            ModConfig.get().apiKey = apiKeyField.method_1882().trim();
            ModConfig.save();
            field_22787.method_1507(parent);
        }).method_46434(centerX - 80, centerY + 10, 75, 20).method_46431());

        // Cancel button
        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"),
                btn -> field_22787.method_1507(parent))
                .method_46434(centerX + 5, centerY + 10, 75, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, field_22785, field_22789 / 2, field_22790 / 2 - 50, 0xFFFFFF);
        context.method_27535(field_22793,
                class_2561.method_43470("Anthropic API key:"), field_22789 / 2 - 150, field_22790 / 2 - 35, 0xAAAAAA);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() { return false; }
}
